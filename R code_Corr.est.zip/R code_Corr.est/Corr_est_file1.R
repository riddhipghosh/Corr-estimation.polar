# ---------------------- RIDDHI PRATIM GHOSH ---------------------
#------------  ----------------
#------------- Below are some useful function ----------------------
# -------------------------------- Generating $R$ matrix ---------------------------------
library(psych)
THETAtoR = function(Theta){
  Theta = Theta[-1,-ncol(Theta)]; Theta = t(Theta)
  d=dim(Theta)[1]
  p = d+1
  theta=matrix(0,p,p)
  theta[,1]=rep(0,p)
  theta[p,]=rep(0,p)
  theta[1:(p-1),2:p]=Theta
  X=matrix(0,p,p)
  X[1,1]=1; k=1; k1=1
  
  for(j in 2:p) {
    X[1,j]=cos(theta[1,j])
  }
  
  for(i in 2:p){
    for( l in 1:(i-1)){
      k1=k1*sin(theta[l,i])
    }
    X[i,i]=k1;
    k1=1;
  }
  
  
  for(i in 2:(p-1)){
    for(j in (i+1):p){
      for(l in 1:(i-1)){
        k=k*sin(theta[l,j])
      }
      X[i,j]= cos(theta[i,j])*k
      k=1;
    }
  }
  return(t(X)%*%X)
  
}

# ------------------------------ Generating $\Theta$ matrix  -------------------------------
RtoTHETA = function(R){
  p = dim(R)[1]
  X = chol(R)
  theta = matrix(0,p,p)
  h = 1
  for(j in 2:p) {
    theta[1,j] = acos(X[1,j])
  }
  for(j in 3:p){
    theta[2,j] = acos(X[2,j]/sin(theta[1,j]))
  }
  for(i in 3:(p-1)){
    for(j in (i+1):p){
      for(l in 1:(i-1)){
        h = h*sin(theta[l,j])
      }
      theta[i,j] = acos(X[i,j]/h)
      h = 1
      
    }
  }
  Theta = matrix(0,p,p)
  Theta[2:p,1:(p-1)] = t(theta[1:(p-1),2:p]);
  
  #return(theta[1:(p-1),2:p])
  return(Theta)
}

#____________________ Cholesky decomposition from theta matrix ________________________

get_R = function(Theta){
  d=dim(Theta)[1]
  p = d+1
  theta=matrix(0,p,p)
  theta[,1]=rep(0,p)
  theta[p,]=rep(0,p)
  theta[1:(p-1),2:p]=Theta
  X=matrix(0,p,p)
  X[1,1]=1; k=1; k1=1
  
  for(j in 2:p) {
    X[1,j]=cos(theta[1,j])
  }
  
  for(i in 2:p){
    for( l in 1:(i-1)){
      k1=k1*sin(theta[l,i])
    }
    X[i,i]=k1;
    k1=1;
  }
  
  
  for(i in 2:(p-1)){
    for(j in (i+1):p){
      for(l in 1:(i-1)){
        k=k*sin(theta[l,j])
      }
      X[i,j]= cos(theta[i,j])*k
      k=1;
    }
  }
  return(t(X))
  
}




dSin = function(theta,alpha,switch){
  out = (1/beta(alpha,1/2))*(sin(theta))^(2*alpha-1)
  if(switch ==1) {
    return(log(out))
  } else {
    return(out)
  }
}

pSin = function(theta,alpha,switch){
  integrand = function(x) {(sin(x))^(2*alpha-1)}
  out = (1/beta(alpha,1/2))*(integrate(integrand,lower = 0, upper = theta)$value)
  if(switch==1) {
    return(log(out))
    } else{
    return(out)
  }
}

qSin = function(prob,alpha){
  x = seq(0,pi,pi/100); lx = length(x); y = rep(NA,lx)
  integrand = function(z) {(sin(z))^(2*alpha-1)}
  for(i in 1:lx) y[i] = (1/beta(alpha,1/2))*(integrate(integrand,lower = 0, upper = x[i])$value)
  if(length(which(y==prob))>=1){
    return(min(x[which(y==prob)]))
  } else {
    u_index = min(which(y>prob)); l_index = max(which(y<prob));
    return(0.5*(x[u_index]+x[l_index]))
  }
}

