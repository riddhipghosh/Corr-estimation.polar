burn.in = 3000		# number of burn-in iterations
niter = 12000 		# number of iterations after burn-in
keep.prop = 1/10 	# proportion of iterations to keep for inference
MCMC.seed = 51184

### Hyperparameter Choices

THETA.beta = 1		#  if Selection prior


eps.sh1 = 1		# first beta shape parameter for epsilon_0
eps.sh2 = 1		# second beta shape parameter for epsilon_0

gamma.alpha = 5		# shape parameter for gamma
gamma.beta = 5 		# rate parameter for gamma

### Slice sampling parameters
thetaslice.width = pi/10	# step width for PAC
thetaslice.steps = 25	# max number of steps for PAC

sw.eps = .02		# step width for epsilon_0
ss.eps = 50		# max number of steps for epsilon_0

sw.gam = .1		# step width for gamma
ss.gam = 20		# max number of steps for gamma


# ---------------------- Shrinkage prior -------------------------

loglik.THETA = function(THETA, R.current=diag(1,p), i1=p, i2=1, R.true=F){
  if( R.true==F){ 
    R = THETAtoR(THETA, R.current, i1, i2)
  } else{
    R = R.current
  }
  -.5*sum(t(data) %*% solve(R) %*%data)  - .5*(n.tot*log(det(R))+log(2*pi)) +
    dSin(THETA[i+k,i], THETA.beta, switch=1)
} 

loglik.hyp = function(eps,gam){
  if( (gam < 1e-8)|( abs(eps-.5) > .5 ) ){ value = -Inf }else {
    value = dgamma( gam, gamma.alpha, gamma.beta, log=T) + 
      dbeta( eps, eps.sh1, eps.sh2, log=T)
    for( k in 1:(p-1) ){
      parm = .5*((k^gam)/eps-1)
      value = value + sum(dSin(*offdiag(THETA,k), parm, switch=1))
    }}
  (value)
}

#---------------------------- Selection prior ----------------------------------

loglik.THETA = function(THETA, R.current=diag(1,p), i1=p, i2=1, R.true=F){
  if( R.true==F){ 
    R = THETAtoR(THETA, R.current, i1, i2)
  } else{
    R = R.current
  }
  -.5*sum(t(data) %*% solve(R) %*%data)  - .5*(n.tot*log(det(R))+log(2*pi))
} 
loglik.hyp = function(eps,gam){
  if( (gam < 1e-8)|( abs(eps-.5) > .5 ) ){ value = -Inf }else {
    value = dgamma( gam, gamma.alpha, gamma.beta, log=T) + 
      dbeta( eps, eps.sh1, eps.sh2, log=T)
    for( k in 1:(p-1) ){
      value = value + sum(offdiag(PI,k) != pi/2)*log(eps*(k^(-gam))) + 
        sum(offdiag(PI,k) == pi/2)*log(1-eps*(k^(-gam)))
    }}
  (value)
}

F.PI = function(x,eps){
 as.numeric( eps*pSin(x, THETA.beta) + (1-eps)*I(x>=0) )
}
Finv.PI = function(y,eps){
  if( y <= eps*pSin(pi/2,THETA.beta,0) ){ 
    value = 2*qSin(y/eps, THETA.beta)-pi }
  if( ( (y > eps*pSin(pi/2,THETA.beta))&
        (y <= 1-eps*(1-pSin(pi/2,THETA.beta)) )) ){
    value = 0 }
  if( y > 1-eps*(1-pSin(pi/2,THETA.beta)) ){
    value = 2*qSin( (y-1+eps)/eps, THETA.beta)-1 }
  (value)
}

#-------------------------- Initialization ------------------
THETA = RtoTHETA(diag(6))
epsilon = .8
gamma = 1
R = diag(6)

#------------------------ MCMC: Shrinkage prior ----------------

  for(j in 1:(p-1)){
    for(k in 1:(p-1)){
     if(k+j<=p){
      THETA.alpha = THETA.beta = .5*((k^gamma)/epsilon-1)
      horiz.slice = loglik.THETA(THETA, R, R.true=T) - rexp(1)
      THETA.temp = THETA
      left.left = THETA[j+k,j] - runif(1,0, pislice.width)
      right.right = left.left + pislice.width
      step.left = floor( runif(1,0, pislice.steps))
      step.right = pislice.steps - step.left - 1
      
      while( step.left > 0 ){
        THETA.temp[j,j+k] = max( 0.001, left.left)
        if( loglik.THETA(THETA.temp, R, j+k, j) < horiz.slice ){
          step.left = 0 } else{
            left.left = left.left - pislice.width
            step.left = step.left - 1
          }
      }
      while( step.right > 0 ){
        THETA.temp[j+k,j] = min( 3.141592, right.right)
        if( loglik.THETA(THETA.temp, R, j+k, j) < horiz.slice ){
          step.right = 0 } else{
            right.right = right.right + pislice.width
            step.right = step.right - 1
          }
      }
      left.left = max( 0.000001, left.left)
      right.right = min( 3.141592, right.right)
      
      stopper = FALSE
      while( stopper == FALSE ){
        THETA.temp[j+k,j] = runif( 1, left.left, right.right)
        stopper = ( loglik.THETA(THETA.temp, R, j, j+k) > horiz.slice )
        if( ( stopper == FALSE )&( THETA[j+k,j]< PI.temp[j+k,j]) ){ 
          right.right = THETA.temp[j+k,j]}
        if( ( stopper == FALSE )&( THETA[j+k,j]> THETA.temp[j+k,j]) ){ 
          left.left = THETA.temp[j+k,j]}	
      }
      THETA[j+k,j] = THETA.temp[j+k,j]
      R = THETAtoR(THETA, R, j+k, j)
     }}}


### Sample PI from modified slice sampling algorithm Selection prior 

for(j in 1:(p-1)){
  for(k in 1:(p-1)){
    if(k+j<=p){
      horiz.slice = loglik.THETA(THETA, R, R.true=T) - rexp(1)
      THETA.temp = THETA
      left.left = THETA[j+k,j] - runif(1,0, pislice.width)
      right.right = left.left + pislice.width
      step.left = floor( runif(1,0, pislice.steps))
      step.right = pislice.steps - step.left - 1
      
      while( step.left > 0 ){
        PI.temp[j,j+k] = max( 0.001, left.left)
        if( loglik.THETA(THETA.temp, R, j+k, j) < horiz.slice ){
          step.left = 0 } else{
            left.left = left.left - pislice.width
            step.left = step.left - 1
          }
      }
      while( step.right > 0 ){
        THETA.temp[j+k,j] = min( 3.141592, right.right)
        if( loglik.THETA(THETA.temp, R, j+k, j) < horiz.slice ){
          step.right = 0 } else{
            right.right = right.right + pislice.width
            step.right = step.right - 1
          }
      }
      left.left = max( 0.000001, left.left)
      right.right = min( 3.141592, right.right)
      
      
      stopper = FALSE
      while( stopper == FALSE ){
        PI.temp[j,j+k] = Finv.THETA( runif( 1, 
                                          F.PI(left.left,epsilon*(k^(-gamma))), 
                                          F.PI(right.right,epsilon*(k^(-gamma)))), epsilon*(k^(-gamma)))
        stopper = ( loglik.THETA(THETA.temp, R, j+k, j) > horiz.slice )
        if( ( stopper == FALSE )&( THETA[j+k,j]< THETA.temp[j+k,j]) ){ 
          right.right = THETA.temp[j+k,j]}
        if( ( stopper == FALSE )&( THETA[j+k,j]> THETA.temp[j+k,j]) ){ 
          left.left = THETA.temp[j+k,j]}	
      }
      THETA[j+k,j] = THETA.temp[j+k,j]
      R = THETAtoR(THETA, R, j+k, j)
    }}}


##################################################
### Sample Epsilon


  horiz.slice = loglik.hyp( epsilon, gamma ) - rexp(1)
  slice.left = epsilon - runif(1,0,sw.eps)
  slice.right = sw.eps + slice.left
  step.left = floor( runif(1,0,ss.eps) )
  step.right = ss.eps - step.left - 1
  
  while( step.left > 0 ){
    if( loglik.hyp(slice.left,gamma) < horiz.slice ){ step.left = 0 
    } else{
      slice.left = slice.left - sw.eps
      step.left = step.left - 1
    }
  }
  while( step.right > 0 ){
    if( loglik.hyp(slice.right,gamma) < horiz.slice ){ step.right = 0 
    } else{
      slice.right = slice.right + sw.eps
      step.right = step.right - 1
    }
  }
  slice.left = max( 0, slice.left)
  slice.right = min( 1, slice.right)
  
  stopper = FALSE
  while( stopper == FALSE ){
    eps = runif(1, slice.left, slice.right)
    stopper = ( loglik.hyp( eps,gamma ) > horiz.slice )
    if( ( stopper == FALSE )&( epsilon < eps) ){ slice.right = eps}
    if( ( stopper == FALSE )&( epsilon > eps) ){ slice.left = eps}	
  }
  epsilon = eps




##################################################
### Sample Gamma

if( corr.choice %in% c(1,2) ){
  horiz.slice = loglik.hyp( epsilon, gamma ) - rexp(1)
  slice.left = gamma - runif(1,0,sw.gam)
  slice.right = sw.gam + slice.left
  step.left = floor( runif(1,0,ss.gam) )
  step.right = ss.gam - step.left - 1
  
  while( step.left > 0 ){
    if( loglik.hyp( epsilon,slice.left) < horiz.slice ){ step.left = 0 
    } else{
      slice.left = slice.left - sw.gam
      step.left = step.left - 1
    }
  }
  while( step.right > 0 ){
    if( loglik.hyp( epsilon,slice.right) < horiz.slice ){ step.right = 0 
    } else{
      slice.right = slice.right + sw.gam
      step.right = step.right - 1
    }
  }
  slice.left = max( 0, slice.left)
  
  stopper = FALSE
  while( stopper == FALSE ){
    gam = runif(1, slice.left, slice.right)
    stopper = ( loglik.hyp( epsilon, gam ) > horiz.slice )
    if( ( stopper == FALSE )&( gamma < gam) ){ slice.right = gam }
    if( ( stopper == FALSE )&( gamma > gam) ){ slice.left = gam }	
  }
  gamma = gam
}






